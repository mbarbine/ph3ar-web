#!/bin/bash
# Commit and push changes to a specified branch
BRANCH_NAME=$1
COMMIT_MESSAGE=$2

git add .
git commit -m "$COMMIT_MESSAGE"
git push -u origin $BRANCH_NAME
