#!/bin/bash
# Initialize git repository and set remote origin
REPO_URL=$1
BRANCH_NAME=$2

git init
git remote add origin $REPO_URL
git checkout -b $BRANCH_NAME
