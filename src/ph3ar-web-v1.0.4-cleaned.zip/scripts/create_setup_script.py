import os

# Write the setup script
setup_script_content = """#!/bin/bash

REPO_DIR="$HOME/Documents/github/phear-web"
REPO_URL="https://github.com/mbarbine/ph3ar-web.git"
BRANCH_NAME="enhancement-style-guide"
COMMIT_MESSAGE="Add style guide and community guidance, update README"

# Navigate to the repository directory
cd $REPO_DIR

# Initialize git repository if not already initialized
if [ ! -d ".git" ];then
    git init
fi

# Set remote origin
git remote add origin $REPO_URL

# Create a new branch
git checkout -b $BRANCH_NAME

# Copy the cleaned files to the repository
cp -r $1/* .

# Add files to git
git add .

# Commit changes
git commit -m "$COMMIT_MESSAGE"

# Push changes
git push -u origin $BRANCH_NAME
"""

scripts_dir = "scripts"
os.makedirs(scripts_dir, exist_ok=True)

with open(os.path.join(scripts_dir, "setup.sh"), "w") as file:
    file.write(setup_script_content)

os.chmod(os.path.join(scripts_dir, "setup.sh"), 0o755)
