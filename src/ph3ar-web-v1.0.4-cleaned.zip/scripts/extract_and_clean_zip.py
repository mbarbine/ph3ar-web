import zipfile
import os
import shutil

# Paths
provided_zip_path = "/mnt/data/ph3ar-web-v1.0.3 3.zip"
extracted_dir = "/mnt/data/ph3ar-web-current-cleaned"

# Extract the provided zip file
with zipfile.ZipFile(provided_zip_path, 'r') as zip_ref:
    zip_ref.extractall(extracted_dir)

# Define .gitignore rules
gitignore_content = """
__pycache__/
*.pyc
.DS_Store
node_modules/
.env
"""

# Write .gitignore to the extracted directory
with open(os.path.join(extracted_dir, ".gitignore"), "w") as file:
    file.write(gitignore_content)

# Clean up the extracted directory based on .gitignore rules
def clean_directory(directory, gitignore):
    for root, dirs, files in os.walk(directory):
        for name in files:
            if any([name.endswith(pattern) for pattern in gitignore.splitlines() if pattern]):
                os.remove(os.path.join(root, name))
        for name in dirs:
            if any([name == pattern.rstrip('/') for pattern in gitignore.splitlines() if pattern.endswith('/')]):
                shutil.rmtree(os.path.join(root, name))

clean_directory(extracted_dir, gitignore_content)
