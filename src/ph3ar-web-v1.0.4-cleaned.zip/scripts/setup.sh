#!/bin/bash

REPO_DIR="$HOME/Documents/github/phear-web"
REPO_URL="https://github.com/mbarbine/ph3ar-web.git"
BRANCH_NAME="enhancement-style-guide"
COMMIT_MESSAGE="Add style guide and community guidance, update README"

# Navigate to the repository directory
cd $REPO_DIR

# Initialize git repository if not already initialized
if [ ! -d ".git" ];then
    git init
fi

# Set remote origin
git remote add origin $REPO_URL

# Create a new branch
git checkout -b $BRANCH_NAME

# Copy the cleaned files to the repository
cp -r $1/* .

# Add files to git
git add .

# Commit changes
git commit -m "$COMMIT_MESSAGE"

# Push changes
git push -u origin $BRANCH_NAME
